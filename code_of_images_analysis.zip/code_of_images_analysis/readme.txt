All this codes are made with python 3.

To run the code to analyze the images:

You need to have all the images to analyze in one folder or directory.

Run the code named W_and_R_cells_determination.py. Here you need to save the resulting images in a folder (this is done by the code, just need to define the directory to save the images) to further analyze them with the particle analysis of Image J software . After obtaining the mask of the image, you need to save it in another folder with the number that correspond to the disc (for example "1.png","2.png",etc.) as the files obtained from the fisrt code (Do it for all the discs).

Next, run the code named Quantification_of_W_and_R_cells_after_particle_analysis.py to obtain a Data Frame with the total number of R and W pixels and cells, also with the distance of the wing pouch in the Dorsal Ventral axis and the wing pouch area for each disc. 

Finally, run the code named for_final_analysis_and_plot.py to group all the discs and obtain some statistics and a to plot the results. 

*The first and the second would last long, depending on your computer capacity. 

For questions send an email to luis.nava@cinvestav.mx

